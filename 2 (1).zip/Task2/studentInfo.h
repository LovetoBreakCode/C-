#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>
using namespace std;

const int MAX_ITEMS = 5;


class studentInfo
{
    struct ItemType{
        int id;
        string name;
        double cgpa;

    };
    public:
        studentInfo();
        ~studentInfo();
        void MakeEmpty();
        bool IsFull();
        int LengthIs();
        void InsertItem(int,string,double);
        void DeleteItem(int);
        void RetrieveItem(int&,string&,double&, bool&);
        void ResetList();
        void GetNextItem(int&, string&, double&);
        void Print();

    protected:

    private:
        int length,currentPos;
        ItemType info[MAX_ITEMS];
};

#endif // STUDENTINFO_H
