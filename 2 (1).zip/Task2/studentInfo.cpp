#include "studentInfo.h"
#include<iostream>
#include<string>
using namespace std;


studentInfo::studentInfo()
{
    length=0;
    currentPos=-1;
}


studentInfo::~studentInfo()
{

}


void
studentInfo::ResetList()
{
    currentPos=-1;
}

void
studentInfo::MakeEmpty()
{
    length=0;
    currentPos=-1;
}


bool
studentInfo::IsFull()
{
    if(length==MAX_ITEMS) return true;
    else return false;
}


int
studentInfo::LengthIs()
{
    return length;
}


void
studentInfo::InsertItem(int i, string n, double c)
{
    int location,index;
    if(length>=MAX_ITEMS) return;
    location=0;
    while(location<length && info[location].id<i)
        location++;
    if(info[location].id==i) return;
    for(index=length; index>location; index--)
    {
        info[index].id=info[index-1].id;
        info[index].name=info[index-1].name;
        info[index].cgpa=info[index-1].cgpa;
    }
    info[location].id=i;
    info[location].name=n;
    info[location].cgpa=c;
    length++;
    return;
}


void
studentInfo::DeleteItem(int i)
{
    int location=0,index;
    while(location<length && info[location].id<i)
        location++;
    if(info[location].id==i)
    {
        for(index=location; index<length-1; index++)
        {
            info[index].id=info[index+1].id;
            info[index].name=info[index+1].name;
            info[index].cgpa=info[index+1].cgpa;
        }
        length--;
    }
}


void
studentInfo::RetrieveItem(int& i,string& n,double& c, bool& found)
{
    int mid,first,last;
    first=0;
    last=length-1;
    while(first<=last && i!=info[mid].id)
    {
    mid=(first+last)/2;
    if(info[mid].id=i)
    {
        found=true;
        n=info[mid].name;
        c=info[mid].cgpa;
        return;
    }
    else if(info[mid].id<i) first=mid+1;
    else last=mid+1;
}
    found=false;
}


void
studentInfo::Print()
{

    for(int i=0; i<length; i++)
    {
        cout<<info[i].id<<" "<<info[i].name<<" "<<info[i].cgpa;
        cout<<endl;
    }

}


void
studentInfo::GetNextItem(int& i, string& n, double& c)
{
    currentPos++;
    i=info[currentPos].id;
    n=info[currentPos].name;
    c=info[currentPos].cgpa;
}

