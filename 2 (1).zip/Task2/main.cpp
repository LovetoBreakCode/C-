#include <iostream>
#include"studentInfo.h"

#include<string>

using namespace std;

int main()
{

    studentInfo s;

    s.InsertItem(15234, "Jon", 2.6);
    s.InsertItem(13732, "Tyrion", 3.9);
    s.InsertItem(13569, "Sandor", 1.2);
    s.InsertItem(15467, "Ramsey", 3.1);
    s.InsertItem(16285, "Arya", 3.1);

    s.DeleteItem(15467);

    int id= 13569;
    string name;
    double cgpa;
    bool found;
    s.RetrieveItem(id,name,cgpa,found);
    if(found==false) cout<<"Item not found"<<endl;
    else {
        cout<<"Item is found"<<endl;
        cout<<id<<" "<<name<<" "<<cgpa<<endl;
    }

    s.Print();
    s.MakeEmpty();

    return 0;
}
